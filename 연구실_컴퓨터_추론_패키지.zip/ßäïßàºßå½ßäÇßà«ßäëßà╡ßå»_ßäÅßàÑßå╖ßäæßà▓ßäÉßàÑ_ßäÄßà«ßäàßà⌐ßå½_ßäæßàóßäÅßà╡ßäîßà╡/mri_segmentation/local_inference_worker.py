"""
연구실 컴퓨터 자동 추론 워커
Django에서 생성한 추론 요청을 자동으로 처리합니다.

사용법:
    # 한 번만 실행
    python local_inference_worker.py
    
    # 백그라운드 실행 (Linux/Mac)
    nohup python local_inference_worker.py > worker.log 2>&1 &
    
    # systemd 서비스로 실행 (권장)
    sudo systemctl start mri-inference-worker
"""
import sys
import os
import time
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('worker.log')
    ]
)
logger = logging.getLogger(__name__)

# 경로 설정
BASE_DIR = Path(__file__).parent
SRC_DIR = BASE_DIR / "src"
sys.path.insert(0, str(SRC_DIR))

# 요청 디렉토리 (Django와 공유)
# 실제 환경에서는 NFS 마운트 또는 공유 스토리지 사용
REQUEST_DIR = Path(os.getenv("REQUEST_DIR", "/tmp/mri_inference_requests"))
REQUEST_DIR.mkdir(exist_ok=True, parents=True)

# 폴링 간격 (초)
POLL_INTERVAL = int(os.getenv("POLL_INTERVAL", "30"))

# 환경 변수
DEVICE = os.getenv("DEVICE", "cuda")
THRESHOLD = float(os.getenv("THRESHOLD", "0.5"))


def process_request(request_file: Path) -> Dict[str, Any]:
    """
    추론 요청 처리
    
    Args:
        request_file: 요청 JSON 파일 경로
    
    Returns:
        처리 결과 딕셔너리
    """
    try:
        # 요청 데이터 읽기
        with open(request_file, 'r', encoding='utf-8') as f:
            request_data = json.load(f)
        
        logger.info(f"📋 요청 처리 시작: {request_file.name}")
        logger.info(f"   - 요청 시간: {request_data.get('requested_at')}")
        logger.info(f"   - 시리즈 개수: {len(request_data.get('series_ids', []))}")
        
        # 상태 확인
        if request_data.get('status') != 'pending':
            logger.info(f"   - 이미 처리됨: {request_data.get('status')}")
            return {'skipped': True, 'status': request_data.get('status')}
        
        # 상태를 'processing'으로 변경
        request_data['status'] = 'processing'
        request_data['started_at'] = datetime.now().isoformat()
        with open(request_file, 'w', encoding='utf-8') as f:
            json.dump(request_data, f, indent=2, ensure_ascii=False)
        
        # 추론 실행
        from local_inference import run_inference_local
        
        result = run_inference_local(
            series_ids=request_data['series_ids'],
            device=DEVICE,
            threshold=THRESHOLD
        )
        
        # 결과 저장
        request_data['status'] = 'completed' if result['success'] else 'failed'
        request_data['completed_at'] = datetime.now().isoformat()
        request_data['result'] = result
        
        with open(request_file, 'w', encoding='utf-8') as f:
            json.dump(request_data, f, indent=2, ensure_ascii=False)
        
        if result['success']:
            logger.info(f"✅ 요청 처리 완료: {request_file.name}")
            logger.info(f"   - Instance ID: {result.get('seg_instance_id')}")
            logger.info(f"   - 소요 시간: {result.get('elapsed_time_seconds', 0):.2f}초")
        else:
            logger.error(f"❌ 요청 처리 실패: {request_file.name}")
            logger.error(f"   - 오류: {result.get('error')}")
        
        return result
        
    except Exception as e:
        logger.error(f"❌ 요청 처리 중 예외 발생: {str(e)}", exc_info=True)
        
        # 오류 상태 저장
        try:
            with open(request_file, 'r', encoding='utf-8') as f:
                request_data = json.load(f)
            request_data['status'] = 'failed'
            request_data['completed_at'] = datetime.now().isoformat()
            request_data['result'] = {'success': False, 'error': str(e)}
            with open(request_file, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False)
        except:
            pass
        
        return {'success': False, 'error': str(e)}


def cleanup_old_requests(max_age_hours: int = 24):
    """
    오래된 요청 파일 정리
    
    Args:
        max_age_hours: 최대 보관 시간 (시간)
    """
    try:
        current_time = time.time()
        for request_file in REQUEST_DIR.glob("*.json"):
            # 파일 수정 시간 확인
            file_age_hours = (current_time - request_file.stat().st_mtime) / 3600
            
            if file_age_hours > max_age_hours:
                # 요청 데이터 확인
                try:
                    with open(request_file, 'r', encoding='utf-8') as f:
                        request_data = json.load(f)
                    
                    # completed 또는 failed 상태만 삭제
                    if request_data.get('status') in ['completed', 'failed']:
                        request_file.unlink()
                        logger.info(f"🧹 오래된 요청 파일 삭제: {request_file.name} (상태: {request_data.get('status')})")
                except Exception as e:
                    logger.warning(f"⚠️ 파일 정리 중 오류: {request_file.name} - {e}")
                    
    except Exception as e:
        logger.warning(f"⚠️ 정리 작업 중 오류: {e}")


def main():
    """메인 워커 루프"""
    logger.info("="*60)
    logger.info("🚀 MRI 세그멘테이션 자동 추론 워커 시작")
    logger.info("="*60)
    logger.info(f"📂 요청 디렉토리: {REQUEST_DIR}")
    logger.info(f"⏱️ 폴링 간격: {POLL_INTERVAL}초")
    logger.info(f"🖥️ 디바이스: {DEVICE}")
    logger.info(f"📊 임계값: {THRESHOLD}")
    logger.info("="*60)
    
    # GPU 사용 가능 여부 확인
    try:
        import torch
        if DEVICE == "cuda" and torch.cuda.is_available():
            logger.info(f"✅ GPU 사용 가능: {torch.cuda.get_device_name(0)}")
        elif DEVICE == "cuda" and not torch.cuda.is_available():
            logger.warning("⚠️ GPU 요청되었으나 사용 불가, CPU 모드로 전환됩니다.")
        else:
            logger.info("ℹ️ CPU 모드로 실행")
    except ImportError:
        logger.warning("⚠️ PyTorch가 설치되지 않았습니다.")
    
    logger.info("\n💡 워커가 실행 중입니다. 종료하려면 Ctrl+C를 누르세요.\n")
    
    processed_count = 0
    
    try:
        while True:
            # 대기 중인 요청 파일 찾기
            request_files = sorted(REQUEST_DIR.glob("*.json"))
            
            if request_files:
                logger.info(f"🔍 {len(request_files)}개 요청 파일 발견")
                
                for request_file in request_files:
                    result = process_request(request_file)
                    
                    if not result.get('skipped'):
                        processed_count += 1
            
            # 오래된 요청 정리 (1시간마다)
            if processed_count % 120 == 0 and processed_count > 0:
                logger.info("🧹 오래된 요청 파일 정리 중...")
                cleanup_old_requests(max_age_hours=24)
            
            # 다음 폴링까지 대기
            time.sleep(POLL_INTERVAL)
            
    except KeyboardInterrupt:
        logger.info("\n\n⏹️ 워커 종료 요청 받음")
        logger.info(f"📊 총 처리된 요청: {processed_count}개")
        logger.info("👋 워커 종료")
        sys.exit(0)
    except Exception as e:
        logger.error(f"❌ 워커 오류: {str(e)}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

# 건양대학교병원 환자관리시스템 - Flask 웹 애플리케이션

## 📋 프로젝트 개요
기존 콘솔 기반 환자관리시스템을 현대적인 웹 인터페이스로 변환한 Flask 애플리케이션입니다.

## 🏥 주요 기능
- **실시간 대시보드**: 환자 수, 우선순위, 진료비 통계
- **환자 관리**: 등록, 수정, 삭제, 검색
- **병원 현황**: 병원별 환자 분포 및 전문분야 통계
- **우선순위 시스템**: 자동 순위 계산 및 업데이트
- **반응형 디자인**: 모바일/태블릿 지원

## 🚀 실행 방법

### 1. 가상환경 활성화
```bash
cd Flask
source flask_env/bin/activate  # macOS/Linux
# 또는
flask_env\Scripts\activate     # Windows
```

### 2. 애플리케이션 실행
```bash
python patient_management_app.py
```

### 3. 웹 브라우저에서 접속
```
http://localhost:5000
```

## 📁 프로젝트 구조
```
Flask/
├── patient_management_app.py    # 메인 Flask 애플리케이션
├── templates/                   # HTML 템플릿
│   ├── base.html               # 기본 레이아웃
│   ├── dashboard.html          # 대시보드
│   ├── patients.html           # 환자 목록
│   ├── add_patient.html        # 환자 등록
│   ├── edit_patient.html       # 환자 수정
│   └── hospitals.html          # 병원 현황
├── static/                     # 정적 파일
│   ├── css/
│   │   └── style.css          # 커스텀 스타일
│   └── js/
│       └── app.js             # JavaScript 기능
└── flask_env/                 # 가상환경
```

## 🎨 화면 구성

### 1. 대시보드 (/)
- 실시간 통계 카드 (총 환자 수, 높은 우선순위, 총 진료비, 병원 수)
- 우선순위 상위 환자 목록 (Top 10)
- 병원 현황 요약
- 빠른 액션 버튼

### 2. 환자 목록 (/patients)
- 전체 환자 목록 테이블
- 순위, 이름, 나이, 질병, 중증도, 우선순위 표시
- 수정/삭제 기능
- 중증도별 통계

### 3. 환자 등록 (/patients/add)
- 환자 정보 입력 폼
- 병원 선택 드롭다운
- 질병 선택
- 중증도 선택 (경증/중등도/중증)

### 4. 환자 수정 (/patients/<id>/edit)
- 기존 환자 정보 수정
- 현재 정보 표시
- 진료비/우선순위 자동 재계산

### 5. 병원 현황 (/hospitals)
- 병원별 환자 수 통계
- 전문분야별 현황
- 환자 수 분포 차트

## 🔧 기술 스택
- **Backend**: Flask (Python)
- **Database**: MySQL (기존 저장 프로시저 활용)
- **Frontend**: Bootstrap 5, HTML5, CSS3, JavaScript
- **Icons**: Bootstrap Icons

## 🎯 주요 특징
- **반응형 디자인**: 모든 디바이스에서 최적화된 사용자 경험
- **실시간 업데이트**: AJAX를 통한 동적 데이터 갱신
- **사용자 친화적 인터페이스**: 직관적인 네비게이션과 시각적 피드백
- **데이터 무결성**: 기존 저장 프로시저를 통한 안전한 데이터 처리
- **성능 최적화**: 효율적인 데이터베이스 쿼리와 캐싱

## 📊 API 엔드포인트
- `GET /`: 대시보드
- `GET /patients`: 환자 목록
- `GET /patients/add`: 환자 등록 페이지
- `POST /patients/add`: 환자 등록 처리
- `GET /patients/<id>/edit`: 환자 수정 페이지
- `POST /patients/<id>/edit`: 환자 수정 처리
- `POST /patients/<id>/delete`: 환자 삭제
- `GET /hospitals`: 병원 현황
- `POST /api/update_ranks`: 우선순위 업데이트 (AJAX)
- `GET /api/dashboard_stats`: 대시보드 통계 (AJAX)

## 🔒 보안 기능
- CSRF 보호 (Flask secret key)
- SQL Injection 방지 (저장 프로시저 사용)
- XSS 방지 (템플릿 자동 이스케이프)
- 입력 유효성 검사

## 🚨 문제 해결

### 데이터베이스 연결 오류
```
[ERROR] DB 연결 실패
```
- 데이터베이스 서버 상태 확인
- 연결 정보 (host, user, password) 확인

### 포트 충돌
```
Address already in use
```
- 다른 포트 사용: `app.run(port=5001)`
- 또는 기존 프로세스 종료

### 템플릿 오류
- `templates/` 폴더 경로 확인
- 템플릿 파일 존재 여부 확인

## 🔄 업데이트 내역
- v1.0: 기본 CRUD 기능 구현
- v1.1: 대시보드 및 통계 기능 추가
- v1.2: 반응형 디자인 적용
- v1.3: AJAX 기능 및 실시간 업데이트

## 📞 지원
문제가 발생하거나 개선 사항이 있으면 개발팀에 문의하세요.

---
**건양대학교병원 환자관리시스템 v1.3**  
*최종 업데이트: 2025년*
